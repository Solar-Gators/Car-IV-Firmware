#ifndef I2C_LCD_H
#define I2C_LCD_H

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"

// void lcd_send_cmd (char cmd);
// void lcd_send_data (char data);
// void lcd_clear (void);
// void lcd_put_cur(int row, int col);
// void lcd_init (void);
// void lcd_send_string (const char *str);
// void I2C_Write_USB_PD(uint16_t Register ,uint8_t *DataW ,uint16_t Length);

#ifdef __cplusplus
}
#endif

#endif // I2C_LCD_H