#ifndef USER_CONFIG_H_
#define USER_CONFIG_H_

#define USE_FREERTOS 1
#define USE_LOGGING 1

#endif  /* USER_CONFIG_H_ */